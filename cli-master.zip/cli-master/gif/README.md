This folder contains all the metadata needed to produce the `.gif` files used
in the root README.

The program used to process the metadata is
https://github.com/faressoft/terminalizer.
